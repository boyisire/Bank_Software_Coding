#include <stdio.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/errno.h>
#include "swConstant.h"
#include "swShmGroup.h"
#include "swNdbstruct.h"
#include "swapi.h"
#include "swShm.h"


/*�����ֵ*/








